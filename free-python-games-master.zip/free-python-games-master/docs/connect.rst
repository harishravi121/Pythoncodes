Connect Four
============

Connect Four, two-player connection game.

.. literalinclude:: ../freegames/connect.py
