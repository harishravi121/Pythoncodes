Bagels
======

Bagels, a number puzzle game.

.. literalinclude:: ../freegames/bagels.py
