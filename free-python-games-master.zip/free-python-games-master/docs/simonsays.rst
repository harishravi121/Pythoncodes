Simon Says
==========

A game of watching and recalling patterns.

.. literalinclude:: ../freegames/simonsays.py
