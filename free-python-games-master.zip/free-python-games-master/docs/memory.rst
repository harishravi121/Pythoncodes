Memory
======

Memory, puzzle game of number pairs.

.. literalinclude:: ../freegames/memory.py
